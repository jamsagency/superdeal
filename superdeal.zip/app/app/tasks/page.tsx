export default function TasksPage() {
  return <h1 className="text-2xl font-bold p-6">Tasks Page</h1>
}

