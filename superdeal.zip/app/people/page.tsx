import { PeopleView } from "@/components/people-view"

export default function PeoplePage() {
  return <PeopleView />
}

