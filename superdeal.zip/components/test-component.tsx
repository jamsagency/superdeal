export function TestComponent() {
  return <div className="bg-red-500 p-4 text-white">Test Component</div>
}

