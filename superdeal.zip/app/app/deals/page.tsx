export default function DealsPage() {
  return <h1 className="text-2xl font-bold p-6">Deals Page</h1>
}

